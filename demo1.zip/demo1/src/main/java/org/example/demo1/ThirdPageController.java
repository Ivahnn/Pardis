package org.example.demo1;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class ThirdPageController {

    @FXML
    private ImageView imageView;

    @FXML
    private Button previousButton;

    @FXML
    private Button nextButton;

    private final Image[] images = {
            new Image("file:src/main/resources/images/baguio.png"),
            new Image("file:src/main/resources/images/batanes.png"),
            new Image("file:src/main/resources/images/palawan.png"),
            new Image("file:src/main/resources/images/Batangas.png"),
            new Image("file:src/main/resources/images/Bohol.png"),
            new Image("file:src/main/resources/images/Siargao.png"),
    };
    private int currentIndex = 0;

    @FXML
    public void initialize() {
        if (images.length > 0) {
            imageView.setImage(images[0]);  // Initialize the ImageView with the first image
        }

        // Set up a timeline to change images every 3 seconds
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(3), event -> nextImage()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void nextImage() {
        currentIndex = (currentIndex + 1) % images.length;
        imageView.setImage(images[currentIndex]);
    }

    @FXML
    private void handleNextButton() {
        nextImage();
    }

    @FXML
    private void handlePreviousButton() {
        currentIndex = (currentIndex - 1 + images.length) % images.length;
        imageView.setImage(images[currentIndex]);
    }







}
